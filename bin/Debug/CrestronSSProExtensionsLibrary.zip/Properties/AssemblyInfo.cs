﻿using System.Reflection;

[assembly: AssemblyTitle("CrestronSSProExtensionsLibrary")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CrestronSSProExtensionsLibrary")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyVersion("1.0.0.*")]

